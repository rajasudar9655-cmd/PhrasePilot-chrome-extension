const starterSnippets = [
  {
    id: "thanks",
    label: "Quick thanks",
    shortcut: "/ty",
    content: "Thank you for your help! I really appreciate it."
  },
  {
    id: "follow-up",
    label: "Friendly follow-up",
    shortcut: "/followup",
    content: "Hi {{name}},\n\nI wanted to follow up on this when you have a moment.\n\nThanks!"
  },
  {
    id: "today",
    label: "Today’s date",
    shortcut: "/today",
    content: "{{date}}"
  }
];

chrome.runtime.onInstalled.addListener(async () => {
  const { snippets } = await chrome.storage.sync.get("snippets");
  if (!Array.isArray(snippets) || snippets.length === 0) {
    await chrome.storage.sync.set({ snippets: starterSnippets });
  }
});
