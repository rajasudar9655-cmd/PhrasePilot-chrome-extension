const list = document.querySelector("#snippet-list");
const count = document.querySelector("#count");
const form = document.querySelector("#snippet-form");
const template = document.querySelector("#snippet-template");

function cleanShortcut(value) {
  const compact = value.trim().replace(/\s+/g, "");
  return compact.startsWith("/") ? compact : `/${compact}`;
}

async function getSnippets() {
  const { snippets = [] } = await chrome.storage.sync.get("snippets");
  return snippets;
}

async function saveSnippets(snippets) {
  await chrome.storage.sync.set({ snippets });
}

function render(snippets) {
  list.replaceChildren();
  count.textContent = `${snippets.length} saved`;
  if (!snippets.length) {
    list.innerHTML = '<p class="empty">No snippets yet. Add one below.</p>';
    return;
  }
  for (const item of snippets) {
    const node = template.content.cloneNode(true);
    node.querySelector(".snippet-label").textContent = item.label;
    node.querySelector(".snippet-shortcut").textContent = item.shortcut;
    node.querySelector(".snippet-content").textContent = item.content;
    node.querySelector(".delete").addEventListener("click", async () => {
      await saveSnippets((await getSnippets()).filter((snippet) => snippet.id !== item.id));
      render(await getSnippets());
    });
    list.append(node);
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const label = document.querySelector("#label").value.trim();
  const shortcut = cleanShortcut(document.querySelector("#shortcut").value);
  const content = document.querySelector("#content").value;
  const snippets = await getSnippets();
  const duplicate = snippets.some((item) => item.shortcut.toLowerCase() === shortcut.toLowerCase());
  if (duplicate) {
    document.querySelector("#shortcut").setCustomValidity("That shortcut is already in use.");
    form.reportValidity();
    return;
  }
  document.querySelector("#shortcut").setCustomValidity("");
  snippets.unshift({ id: crypto.randomUUID(), label, shortcut, content });
  await saveSnippets(snippets);
  form.reset();
  render(snippets);
});

document.querySelector("#shortcut").addEventListener("input", (event) => event.target.setCustomValidity(""));
getSnippets().then(render);
