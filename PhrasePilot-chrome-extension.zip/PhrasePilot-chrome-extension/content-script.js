let snippetsByShortcut = new Map();

function normaliseShortcut(value) {
  return String(value || "").trim().toLowerCase();
}

function refreshSnippets(items) {
  snippetsByShortcut = new Map(
    (Array.isArray(items) ? items : [])
      .filter((item) => item && item.shortcut && item.content != null)
      .map((item) => [normaliseShortcut(item.shortcut), item])
  );
}

chrome.storage.sync.get({ snippets: [] }).then(({ snippets }) => refreshSnippets(snippets));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && changes.snippets) refreshSnippets(changes.snippets.newValue);
});

function isTextControl(element) {
  return element instanceof HTMLTextAreaElement ||
    (element instanceof HTMLInputElement && /^(text|search|url|email|tel)$/i.test(element.type));
}

function isEditable(element) {
  return isTextControl(element) || Boolean(element?.isContentEditable);
}

function renderTemplate(template) {
  const now = new Date();
  return String(template)
    .replaceAll("{{date}}", now.toLocaleDateString())
    .replaceAll("{{time}}", now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }))
    .replace(/{{name}}/g, "there");
}

function shortcutAtEnd(text) {
  const match = text.match(/(?:^|\s)(\/[\w-]+)$/u);
  return match ? match[1] : null;
}

function replacementFor(shortcut, trailing) {
  const snippet = snippetsByShortcut.get(normaliseShortcut(shortcut));
  if (!snippet) return null;
  return `${renderTemplate(snippet.content)}${trailing}`;
}

function replaceInTextControl(element, shortcut, replacement) {
  const end = element.selectionStart;
  const start = end - shortcut.length;
  element.setRangeText(replacement, start, end, "end");
  element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: replacement }));
}

function replaceInContentEditable(shortcut, replacement) {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) return false;
  const range = selection.getRangeAt(0);
  if (!range.collapsed || range.startContainer.nodeType !== Node.TEXT_NODE) return false;

  const textNode = range.startContainer;
  const start = range.startOffset - shortcut.length;
  if (start < 0 || textNode.textContent.slice(start, range.startOffset) !== shortcut) return false;

  range.setStart(textNode, start);
  range.deleteContents();
  const replacementNode = document.createTextNode(replacement);
  range.insertNode(replacementNode);
  range.setStartAfter(replacementNode);
  range.collapse(true);
  selection.removeAllRanges();
  selection.addRange(range);
  textNode.parentElement?.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: replacement }));
  return true;
}

document.addEventListener("keydown", (event) => {
  if (event.defaultPrevented || event.isComposing || event.ctrlKey || event.metaKey || event.altKey) return;
  if (event.key !== " " && event.key !== "Tab") return;

  const active = document.activeElement;
  if (!isEditable(active)) return;

  if (isTextControl(active)) {
    const cursor = active.selectionStart;
    if (cursor == null || active.selectionStart !== active.selectionEnd) return;
    const shortcut = shortcutAtEnd(active.value.slice(0, cursor));
    const replacement = shortcut && replacementFor(shortcut, event.key === " " ? " " : "");
    if (!replacement) return;
    event.preventDefault();
    replaceInTextControl(active, shortcut, replacement);
    return;
  }

  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) return;
  const range = selection.getRangeAt(0);
  if (!range.collapsed || range.startContainer.nodeType !== Node.TEXT_NODE) return;
  const shortcut = shortcutAtEnd(range.startContainer.textContent.slice(0, range.startOffset));
  const replacement = shortcut && replacementFor(shortcut, event.key === " " ? " " : "");
  if (!replacement) return;
  event.preventDefault();
  replaceInContentEditable(shortcut, replacement);
}, true);
