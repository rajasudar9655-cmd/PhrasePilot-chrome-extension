# PhrasePilot Chrome extension

PhrasePilot is a clean-room, local-first text-expander Chrome extension inspired by the public workflow described by Text Blaze: save a text snippet, assign a shortcut, and expand it in web text fields.

## Included

- Snippet manager in the extension popup
- Chrome Sync storage for snippets
- Expansion in standard inputs, textareas, and many `contenteditable` editors
- Trigger with Space or Tab after a shortcut
- Lightweight `{{date}}`, `{{time}}`, and `{{name}}` template tokens

## Install locally

1. Open `chrome://extensions` in Chrome.
2. Enable **Developer mode**.
3. Choose **Load unpacked**.
4. Select this `blaze-style-expander` folder.

Try `/ty` followed by Space in a normal web text field.

## Deliberate scope

This is not a copy of Text Blaze. It does not use its branding, source code, user accounts, collaboration, integrations, form engine, analytics, or cloud dashboard.
